﻿using System;
using System.Collections.Generic;

namespace BookStore
{
    public class Book
    {
        public long ISBN { get; private set; }
        public List<Author> Szerzok { get; private set; }
        public string Cim { get; private set; }
        public int Kiadas { get; private set; }
        public string Nyelv { get; private set; }
      
        public int Keszlet { get; set; }
        public int Ar { get; private set; }

        
        public Book(long isbn, List<Author> szerzok, string cim, int kiadas, string nyelv, int keszlet, int ar)
        {
            if (isbn.ToString().Length != 10 || keszlet < 0 || ar < 1000 || ar > 10000 || ar % 100 != 0)
            {
                throw new ArgumentException("Nem megfelelő lönyvadatok");
            }

            ISBN = isbn;
            Szerzok = szerzok;
            Cim = cim;
            Kiadas = kiadas;
            Nyelv = nyelv;
            Keszlet = keszlet;
            Ar = ar;
        }

        
        public Book(string cim, string szerzoNev)
        {
            ISBN = RandomISBN();
            Szerzok = new List<Author> { new Author(szerzoNev) };
            Cim = cim;
            Kiadas = 2024;
            Nyelv = "magyar";
            Keszlet = 0;
            Ar = 4500;
        }

        private long RandomISBN()
        {
            Random random = new Random();
            int isbn;

            do
            {
                isbn = random.Next(1000000000, 999999999);
            } while (!uniqueISBN(isbn)); 

            return isbn;
        }

        private bool uniqueISBN(long isbn)
        {
            
            return true; 
        }

        public override string ToString()
        {
            string authorLabel = Szerzok.Count == 1 ? "szerző:" : "szerzők:";
            string KeszletInfo = Keszlet > 0 ? $"{Keszlet} db" : "beszerzés alatt";

            return $"{authorLabel} {string.Join(", ", Szerzok.ConvertAll(a => $"{a.knev} {a.vnev}"))}, Cím: {Cim}, Kiadás: {Kiadas}, Nyelv: {Nyelv}, Készlet: {KeszletInfo}, Ár: {Ar} Ft";
        }
    }
}