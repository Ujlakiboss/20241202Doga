﻿using System;

namespace BookStore
{
    public class Author
    {
        public string knev { get; private set; }
        public string vnev { get; private set; }
        public Guid Id { get; private set; }

        public Author(string tnev)
        {
            var nev = tnev.Trim().Split(' ');

            if (nev.Length != 2 ||
                nev[0].Length < 3 || nev[0].Length > 32 ||
                nev[1].Length < 3 || nev[1].Length > 32)
            {
                throw new ArgumentException("Nem megfelelő");
            }

            knev = nev[0];
            vnev = nev[1];
            Id = Guid.NewGuid();
        }
    }
}